</div>

<div class="p-tag">
<a href=""><p>Disclaimer: Our attempt in this 'Virtual Memorial' is to collect all Martyr's information and put it up under one banner so that people from all walk of life can pay their respect to the Unsung Heroes.  We have collected information from open source i.e. internet. We will soon be starting the process of collecting information from official sources. Any errors are purely unintentional. This is work in progress.</p></a>

</div>
<div class="footer"></div>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
<script src="<?php echo base_url('frontassets/js/jquery.hoverdir.js'); ?>"></script>

<script type="text/javascript">
			$(function() {
			
				$(' #da-thumbs > li ').each( function() { $(this).hoverdir(); } );

			});
		</script>

</body>


</html>