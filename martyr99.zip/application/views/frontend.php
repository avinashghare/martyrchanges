<?php

$this->load->view("frontend/header");
$this->load->view("frontend/$page");
$this->load->view("frontend/footer");


?>